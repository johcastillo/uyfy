from django.apps import AppConfig


class Evaluacion2AppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Evaluacion2App'
